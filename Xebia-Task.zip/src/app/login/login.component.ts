import { Component, OnInit } from '@angular/core';
//import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from  '@angular/forms';
import { Router } from  '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginPopup:boolean = true;
  //userName: any;
  loginForm: FormGroup;
  isSubmitted  =  false;

userList: Array<any> = [
    {
      username: "abcd",
      password: "12345"    
    },
   
    
  ]

  
  constructor(private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.loginForm  =  this.formBuilder.group({
      username: ['', Validators.required],
        password: ['', Validators.required]
    });
}

get formControls() { return this.loginForm.controls; }

login(){
  //debugger;
  console.log(this.loginForm.value);
  this.isSubmitted = true;
  if(this.loginForm.invalid){
    return;
  }
localStorage.setItem('test', JSON.stringify(this.loginForm.value));

    for (let i = 0; i < this.userList.length; i++) {
    if (this.loginForm.value.username == this.userList[i]['username'] &&
     this.loginForm.value.password == this.userList[i]['password']) {
      this.router.navigateByUrl('productList');
      this.loginPopup = false;
    }

      else{
        this.loginPopup = true;
      }
        
    
  }

}
 }
 